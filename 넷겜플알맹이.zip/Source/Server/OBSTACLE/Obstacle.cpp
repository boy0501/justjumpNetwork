#include "Obstacle.h"



Obstacle::Obstacle()
{

}

Obstacle::~Obstacle()
{

}

void Obstacle::update(float deltatime)
{

}