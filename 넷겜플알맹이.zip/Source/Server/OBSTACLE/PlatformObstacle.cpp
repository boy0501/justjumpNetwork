#include "PlatformObstacle.h"

PlatformObstacle::PlatformObstacle()
{

}

PlatformObstacle::~PlatformObstacle()
{

}

void PlatformObstacle::update(float deltatime)
{

}
