#include "Interact.h"


Interact::Interact()
{

}

Interact::~Interact()
{

}

void Interact::update(float deltatime)
{

}